package ccpGuard.crypt;

public final class ProtectionCrypt {
    boolean _inited = false;
    byte[] state = new byte[256];
    int f0x;
    int f1y;

    final int arcfour_byte() {
        int x = (this.f0x + 1) & 255;
        int sx = this.state[x];
        int y = (this.f1y + sx) & 255;
        int sy = this.state[y];
        this.f0x = x;
        this.f1y = y;
        this.state[y] = (byte) (sx & 255);
        this.state[x] = (byte) (sy & 255);
        return this.state[(sx + sy) & 255];
    }

    public synchronized void encrypt(byte[] src, int srcOff, byte[] dest, int destOff, int len) {
        if (this._inited) {
            int end = srcOff + len;
            int si = srcOff;
            int di = destOff;
            while (si < end) {
                dest[di] = (byte) ((src[si] ^ arcfour_byte()) & 255);
                si++;
                di++;
            }
        }
    }

    public void decrypt(byte[] src, int srcOff, byte[] dest, int destOff, int len) {
        encrypt(src, srcOff, dest, destOff, len);
    }

    public void setKey(byte[] key) {
        int counter;
        this.f0x = 0;
        this.f1y = 0;
        for (counter = 0; counter < 256; counter++) {
            this.state[counter] = (byte) counter;
        }
        int keyindex = 0;
        int stateindex = 0;
        for (counter = 0; counter < 256; counter++) {
            int t = this.state[counter];
            stateindex = ((key[keyindex] + stateindex) + t) & 255;
            int u = this.state[stateindex];
            this.state[stateindex] = (byte) (t & 255);
            this.state[counter] = (byte) (u & 255);
            keyindex++;
            if (keyindex >= key.length) {
                keyindex = 0;
            }
        }
        this._inited = true;
    }

    public boolean isInited() {
        return this._inited;
    }

    public static int getValue(int index) {
        return ProtectData.getValue(index);
    }
}
