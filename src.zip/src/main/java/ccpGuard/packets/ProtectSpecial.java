package ccpGuard.packets;

import java.util.logging.Logger;
import ru.l2f.gameserver.model.L2World;
import ru.l2f.gameserver.serverpackets.L2GameServerPacket;
import ru.l2f.gameserver.tables.FakePlayersTable;

public class ProtectSpecial extends L2GameServerPacket {
    private static final String _S__B0_PROTECTSPECIAL = "[S] B0 ProtectSpecial";
    protected static Logger _log = Logger.getLogger(ProtectSpecial.class.getName());
    private static final String anyString = "";

    protected final void writeImpl() {
        writeC(176);
        writeD(L2World.getAllPlayersCount() + FakePlayersTable.getFakePlayersCount());
        writeS(anyString);
    }

    public String getType() {
        return _S__B0_PROTECTSPECIAL;
    }
}
