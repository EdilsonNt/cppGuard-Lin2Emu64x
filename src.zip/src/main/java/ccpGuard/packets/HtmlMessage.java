package ccpGuard.packets;

import java.util.ArrayList;
import java.util.logging.Logger;
import ru.l2f.gameserver.model.L2Player;
import ru.l2f.gameserver.network.L2GameClient;
import ru.l2f.gameserver.serverpackets.L2GameServerPacket;
import ru.l2f.util.Files;

public class HtmlMessage extends L2GameServerPacket {
    private static final String _S__19_NPCHTMLMESSAGE = "[S] 19 NpcHtmlMessage";
    private static final Logger _log = Logger.getLogger(HtmlMessage.class.getName());
    private String _file = null;
    private String _html;
    private int _npcObjId;
    private boolean can_writeImpl = false;
    private boolean have_appends = false;
    private int item_id = 0;
    private ArrayList<String> replaces = new ArrayList();

    public HtmlMessage(int npcObjId) {
        this._npcObjId = npcObjId;
    }

    public final HtmlMessage setHtml(String text) {
        if (!text.contains("<html>")) {
            text = "<html><body>" + text + "</body></html>";
        }
        this._html = text;
        return this;
    }

    public final HtmlMessage setFile(String file) {
        this._file = file;
        return this;
    }

    public final HtmlMessage setItemId(int _item_id) {
        this.item_id = _item_id;
        return this;
    }

    private void setFile() {
        String content = loadHtml(this._file, ((L2GameClient) getClient()).getPlayer());
        if (content == null) {
            String str = (this.have_appends && this._file.endsWith(".htm")) ? "" : this._file;
            setHtml(str);
            return;
        }
        setHtml(content);
    }

    protected String loadHtml(String name, L2Player player) {
        return Files.read(name, player);
    }

    protected String html_load(String name, String lang) {
        String content = Files.read(name, lang);
        if (content == null) {
            return "Can't find file'" + name + "'";
        }
        return content;
    }

    public void replace(String pattern, String value) {
        this.replaces.add(pattern);
        this.replaces.add(value);
    }

    public final void runImpl() {
        if (this._file != null) {
            setFile();
        }
        for (int i = 0; i < this.replaces.size(); i += 2) {
            this._html = this._html.replaceAll((String) this.replaces.get(i), (String) this.replaces.get(i + 1));
        }
        this._html = this._html.replaceAll("%objectId%", String.valueOf(this._npcObjId));
        if (this._html.length() > 8192) {
            this._html = "<html><body><center>Sorry, to long html.</center></body></html>";
        }
        this.can_writeImpl = true;
    }

    protected final void writeImpl() {
        if (this.can_writeImpl) {
            writeC(25);
            writeD(this._npcObjId);
            writeS(this._html);
            writeD(this.item_id);
        }
    }

    public String getType() {
        return _S__19_NPCHTMLMESSAGE;
    }
}
