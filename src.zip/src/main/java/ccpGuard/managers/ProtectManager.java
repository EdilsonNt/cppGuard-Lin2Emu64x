package ccpGuard.managers;

import ccpGuard.ConfigProtect;
import ccpGuard.ProtectInfo;
import java.util.ArrayList;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ScheduledFuture;
import java.util.logging.Logger;
import ru.l2f.database.DatabaseUtils;
import ru.l2f.database.FiltredPreparedStatement;
import ru.l2f.database.L2DatabaseFactory;
import ru.l2f.database.ThreadConnection;
import ru.l2f.gameserver.ThreadPoolManager;
import ru.l2f.gameserver.cache.Msg;
import ru.l2f.gameserver.model.L2Player;
import ru.l2f.gameserver.model.L2World;
import ru.l2f.gameserver.serverpackets.L2GameServerPacket;
import ru.l2f.util.Log;

public class ProtectManager {
    private static ScheduledFuture<GGTask> _GGTask = null;
    private static ProtectManager _instance;
    protected static Logger _log = Logger.getLogger(ProtectManager.class.getName());
    private static String _logFile = "ProtectManager";
    private static String _logMainFile = "protection_logs";
    private static ConcurrentHashMap<String, InfoSet> _objects = new ConcurrentHashMap();

    class GGTask implements Runnable {
        GGTask() {
        }

        public void run() {
            long time = System.currentTimeMillis();
            for (InfoSet object : ProtectManager._objects.values()) {
                if (time - object._lastGGSendTime >= ConfigProtect.PROTECT_GG_SEND_INTERVAL) {
                    try {
                        L2World.getPlayer(object._playerName).sendPacket(new L2GameServerPacket[]{Msg.GameGuardQuery});
                        object._lastGGSendTime = time;
                        object._lastGGRecvTime = (ConfigProtect.PROTECT_GG_RECV_INTERVAL + time) + 1;
                    } catch (Exception e) {
                        ProtectManager.this.removePlayer(object._playerName);
                    }
                }
                if (time - object._lastGGRecvTime >= ConfigProtect.PROTECT_GG_RECV_INTERVAL) {
                    try {
                        L2Player player = L2World.getPlayer(object._playerName);
                        if (!player.getNetConnection().isGameGuardOk()) {
                            if (object._attempts < 3) {
                                object._attempts++;
                            } else {
                                if (player != null) {
                                    Log.add("Player was kicked because GG packet not receive (3 attempts)|" + player.getNetConnection()._prot_info.toString(), ProtectManager._logMainFile);
                                }
                                player.logout(false, false, true);
                            }
                        }
                        object._lastGGRecvTime = time;
                    } catch (Exception e2) {
                        ProtectManager.this.removePlayer(object._playerName);
                    }
                }
            }
            time = System.currentTimeMillis() - time;
            if (time > ConfigProtect.PROTECT_TASK_GG_INVERVAL) {
                Log.add("ALERT! TASK_SAVE_INTERVAL is too small, time to save characters in Queue = " + time + ", Config=" + ConfigProtect.PROTECT_TASK_GG_INVERVAL, ProtectManager._logMainFile);
            }
        }
    }

    private class InfoSet {
        public String _HWID = "";
        public int _attempts;
        public long _lastGGRecvTime;
        public long _lastGGSendTime;
        public String _playerName = "";

        public InfoSet(String name, String HWID) {
            this._playerName = name;
            this._lastGGSendTime = System.currentTimeMillis();
            this._lastGGRecvTime = this._lastGGSendTime;
            this._attempts = 0;
            this._HWID = HWID;
        }
    }

    public void addPlayer(ProtectInfo pi) {
        if (_objects.containsKey(Integer.valueOf(pi.getPlayerId())) && ConfigProtect.PROTECT_DEBUG) {
            Log.add("trying to add player that already exists", _logFile);
            return;
        }
        storeHWID(pi);
        _objects.put(pi.getPlayerName(), new InfoSet(pi.getPlayerName(), pi.getHWID()));
        if (ConfigProtect.PROTECT_DEBUG) {
            Log.add(pi.toString(), _logFile);
        }
    }

    public void removePlayer(String name) {
        if (_objects.containsKey(name)) {
            _objects.remove(name);
        } else if (ConfigProtect.PROTECT_DEBUG) {
            Log.add("trying to remove player that non exists : " + name, _logFile);
        }
    }

    public ProtectManager() {
        startGGTask();
    }

    public static void Shutdown() {
        stopGGTask(false);
    }

    public static ProtectManager getInstance() {
        if (_instance == null) {
            _log.info("Initializing ProtectManager");
            _instance = new ProtectManager();
        }
        return _instance;
    }

    public void startGGTask() {
        stopGGTask(true);
        if (ConfigProtect.PROTECT_ENABLE_GG_SYSTEM) {
            _GGTask = ThreadPoolManager.getInstance().scheduleGeneralAtFixedRate(new GGTask(), ConfigProtect.PROTECT_TASK_GG_INVERVAL, ConfigProtect.PROTECT_TASK_GG_INVERVAL);
        }
    }

    public static void stopGGTask(boolean mayInterruptIfRunning) {
        if (_GGTask != null) {
            try {
                _GGTask.cancel(mayInterruptIfRunning);
            } catch (Exception e) {
            }
            _GGTask = null;
        }
    }

    public int getCountByHWID(String HWID) {
        int result = 0;
        for (InfoSet object : _objects.values()) {
            if (object._HWID.equals(HWID)) {
                result++;
            }
        }
        return result;
    }

    public ArrayList<String> getNamesByHWID(String HWID) {
        ArrayList<String> names = new ArrayList();
        for (InfoSet object : _objects.values()) {
            if (object._HWID.equals(HWID)) {
                names.add(object._playerName);
            }
        }
        return names;
    }

    public void storeHWID(ProtectInfo pi) {
        ThreadConnection con = null;
        FiltredPreparedStatement statement = null;
        try {
            con = L2DatabaseFactory.getInstance().getConnection();
            statement = con.prepareStatement("UPDATE characters SET LastHWID=? WHERE obj_id=?");
            statement.setString(1, pi.getHWID());
            statement.setInt(2, pi.getPlayerId());
            statement.execute();
        } catch (Exception e) {
            _log.warning("could not store characters HWID:" + e);
        } finally {
            DatabaseUtils.closeDatabaseCS(con, statement);
        }
    }
}
