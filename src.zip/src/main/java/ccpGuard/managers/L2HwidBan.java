package ccpGuard.managers;

public class L2HwidBan {
    private String HWID;
    private final int _id;

    public L2HwidBan(int id) {
        this._id = id;
    }

    public int getId() {
        return this._id;
    }

    public void setHwidBan(String hwid1) {
        this.HWID = hwid1;
    }

    public String getHwid() {
        return this.HWID;
    }
}
