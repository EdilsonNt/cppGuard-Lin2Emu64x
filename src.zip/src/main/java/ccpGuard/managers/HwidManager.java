package ccpGuard.managers;

import ccpGuard.ProtectInfo;
import ccpGuard.managers.HwidInfo.LockType;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;
import ru.l2f.database.DatabaseUtils;
import ru.l2f.database.FiltredPreparedStatement;
import ru.l2f.database.L2DatabaseFactory;
import ru.l2f.database.ThreadConnection;
import ru.l2f.gameserver.model.L2Player;
import ru.l2f.gameserver.network.L2GameClient;

public class HwidManager {
    private static HwidManager _instance;
    static Map<Integer, HwidInfo> _listHWID;
    private static final Logger _log = Logger.getLogger(HwidManager.class.getName());

    public static HwidManager getInstance() {
        if (_instance == null) {
            _instance = new HwidManager();
        }
        return _instance;
    }

    public HwidManager() {
        _listHWID = new HashMap();
        load();
        _log.config("HWIDManager: Loaded " + _listHWID.size() + " HWIDs");
    }

    private void load() {
        ThreadConnection con = null;
        FiltredPreparedStatement statement = null;
        ResultSet rset = null;
        try {
            con = L2DatabaseFactory.getInstance().getConnection();
            statement = con.prepareStatement("SELECT * FROM hwid_info");
            rset = statement.executeQuery();
            int counterHwidInfo = 0;
            while (rset.next()) {
                HwidInfo hInfo = new HwidInfo(counterHwidInfo);
                hInfo.setHwids(rset.getString("HWID"));
                hInfo.setCount(rset.getInt("WindowsCount"));
                hInfo.setLogin(rset.getString("Account"));
                hInfo.setPlayerID(rset.getInt("PlayerID"));
                hInfo.setLockType(LockType.valueOf(rset.getString("LockType")));
                _listHWID.put(Integer.valueOf(counterHwidInfo), hInfo);
                counterHwidInfo++;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DatabaseUtils.closeDatabaseCSR(con, statement, rset);
        }
    }

    public static void reload() {
        _instance = new HwidManager();
    }

    public static boolean checkLockedHWID(ProtectInfo pi) {
        if (_listHWID.size() == 0) {
            return false;
        }
        boolean result = false;
        int i = 0;
        while (i < _listHWID.size()) {
            switch (((HwidInfo) _listHWID.get(Integer.valueOf(i))).getLockType()) {
                case PLAYER_LOCK:
                    if (pi.getPlayerId() != 0 && ((HwidInfo) _listHWID.get(Integer.valueOf(i))).getPlayerID() == pi.getPlayerId()) {
                        if (!((HwidInfo) _listHWID.get(Integer.valueOf(i))).getHWID().equals(pi.getHWID())) {
                            result = true;
                            break;
                        }
                        return false;
                    }
                case ACCOUNT_LOCK:
                    if (((HwidInfo) _listHWID.get(Integer.valueOf(i))).getLogin().equals(pi.getLoginName())) {
                        if (!((HwidInfo) _listHWID.get(Integer.valueOf(i))).getHWID().equals(pi.getHWID())) {
                            result = true;
                            break;
                        }
                        return false;
                    }
                    continue;
                default:
                    break;
            }
            i++;
        }
        return result;
    }

    public static int getAllowedWindowsCount(ProtectInfo pi) {
        if (_listHWID.size() == 0) {
            return -1;
        }
        int i = 0;
        while (i < _listHWID.size()) {
            if (!((HwidInfo) _listHWID.get(Integer.valueOf(i))).getHWID().equals(pi.getHWID())) {
                i++;
            } else if (((HwidInfo) _listHWID.get(Integer.valueOf(i))).getHWID().equals("")) {
                return -1;
            } else {
                return ((HwidInfo) _listHWID.get(Integer.valueOf(i))).getCount();
            }
        }
        return -1;
    }

    public static int getCountHwidInfo() {
        return _listHWID.size();
    }

    public static void updateHwidInfo(L2Player player, LockType lockType) {
        updateHwidInfo(player, 1, lockType);
    }

    public static void updateHwidInfo(L2Player player, int windowscount) {
        updateHwidInfo(player, windowscount, LockType.NONE);
    }

    public static void updateHwidInfo(L2Player player, int windowsCount, LockType lockType) {
        L2GameClient client = player.getNetConnection();
        int counterHwidInfo = _listHWID.size();
        boolean isFound = false;
        for (int i = 0; i < _listHWID.size(); i++) {
            if (((HwidInfo) _listHWID.get(Integer.valueOf(i))).getHWID().equals(client._prot_info.getHWID())) {
                isFound = true;
                counterHwidInfo = i;
                break;
            }
        }
        ThreadConnection threadConnection = null;
        FiltredPreparedStatement filtredPreparedStatement = null;
        HwidInfo hInfo = new HwidInfo(counterHwidInfo);
        hInfo.setHwids(client._prot_info.getHWID());
        hInfo.setCount(windowsCount);
        hInfo.setLogin(client.getLoginName());
        hInfo.setPlayerID(player.getObjectId());
        hInfo.setLockType(lockType);
        _listHWID.put(Integer.valueOf(counterHwidInfo), hInfo);
        if (isFound) {
            try {
                threadConnection = L2DatabaseFactory.getInstance().getConnection();
                filtredPreparedStatement = threadConnection.prepareStatement("UPDATE hwid_info SET WindowsCount=?,Account=?,PlayerID=?,LockType=? WHERE HWID=?");
                filtredPreparedStatement.setInt(1, windowsCount);
                filtredPreparedStatement.setString(2, client.getLoginName());
                filtredPreparedStatement.setInt(3, player.getObjectId());
                filtredPreparedStatement.setString(4, lockType.toString());
                filtredPreparedStatement.setString(5, client._prot_info.getHWID());
                filtredPreparedStatement.execute();
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                DatabaseUtils.closeDatabaseCS(threadConnection, filtredPreparedStatement);
            }
            return;
        }
        try {
            threadConnection = L2DatabaseFactory.getInstance().getConnection();
            filtredPreparedStatement = threadConnection.prepareStatement("INSERT INTO hwid_info (HWID, WindowsCount, Account, PlayerID, LockType) values (?,?,?,?,?)");
            filtredPreparedStatement.setString(1, client._prot_info.getHWID());
            filtredPreparedStatement.setInt(2, windowsCount);
            filtredPreparedStatement.setString(3, client.getLoginName());
            filtredPreparedStatement.setInt(4, player.getObjectId());
            filtredPreparedStatement.setString(5, lockType.toString());
            filtredPreparedStatement.execute();
            DatabaseUtils.closeStatement(filtredPreparedStatement);
        } catch (Exception e2) {
            e2.printStackTrace();
        } finally {
            DatabaseUtils.closeDatabaseCS(threadConnection, filtredPreparedStatement);
        }
    }
}
