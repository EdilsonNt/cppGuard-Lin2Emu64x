package ccpGuard.managers;

public class HwidInfo {
    private String HWID;
    private final int _id;
    private int count;
    private LockType lockType;
    private String login;
    private int playerID;

    public enum LockType {
        PLAYER_LOCK,
        ACCOUNT_LOCK,
        NONE
    }

    public HwidInfo(int id) {
        this._id = id;
    }

    public int get_id() {
        return this._id;
    }

    public void setHwids(String hwid) {
        this.HWID = hwid;
        this.count = 1;
    }

    public String getHWID() {
        return this.HWID;
    }

    public void setHWID(String HWID) {
        this.HWID = HWID;
    }

    public int getPlayerID() {
        return this.playerID;
    }

    public void setPlayerID(int playerID) {
        this.playerID = playerID;
    }

    public String getLogin() {
        return this.login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public LockType getLockType() {
        return this.lockType;
    }

    public void setLockType(LockType lockType) {
        this.lockType = lockType;
    }

    public int getCount() {
        return this.count;
    }

    public void setCount(int count) {
        this.count = count;
    }
}
