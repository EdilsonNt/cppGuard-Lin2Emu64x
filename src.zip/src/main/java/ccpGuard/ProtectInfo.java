package ccpGuard;

import ccpGuard.packets.ProtectSpecial;
import java.util.concurrent.ScheduledFuture;
import ru.l2f.gameserver.ThreadPoolManager;
import ru.l2f.gameserver.network.L2GameClient;

public class ProtectInfo {
    private String HWID;
    private String HWIDSec;
    private String IP;
    private String _loginName;
    private ScheduledFuture _onlinerTask;
    private int _playerId;
    private String _playerName;
    private int _protectPenalty;
    private L2GameClient client;
    private ProtectionClientState protectState;
    public boolean protect_used;

    private class Onliner implements Runnable {
        private final L2GameClient targetClient;

        public Onliner(L2GameClient client) {
            this.targetClient = client;
        }

        public void run() {
            try {
                this.targetClient.sendPacket(new ProtectSpecial());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public enum ProtectionClientState {
        ENABLED,
        DISABLED,
        LIMITED
    }

    public ProtectInfo(L2GameClient client, String ip, boolean offline) {
        boolean z = false;
        this._protectPenalty = 0;
        this._loginName = "";
        this._playerName = "";
        this._playerId = 0;
        this.HWID = "";
        this.HWIDSec = "";
        this.IP = "";
        this._onlinerTask = null;
        this.protect_used = false;
        this.protect_used = ConfigProtect.PROTECT_ENABLE;
        if (offline) {
            this.protectState = ProtectionClientState.ENABLED;
        } else {
            this.protectState = ProtectionClientState.DISABLED;
        }
        this.IP = ip;
        if (this.protect_used) {
            if (!ConfigProtect.PROTECT_UNPROTECTED_IPS.isIpInNets(ip)) {
                z = true;
            }
            this.protect_used = z;
            this.client = client;
        }
    }

    public final L2GameClient getClient() {
        return this.client;
    }

    public final String getHWID() {
        return this.HWID;
    }

    public void setHWID(String hwid) {
        this.HWID = hwid;
    }

    public final String getHWIDSec() {
        return this.HWIDSec;
    }

    public void setHWIDSec(String hwid) {
        this.HWIDSec = hwid;
    }

    public int getProtectPenalty() {
        return this._protectPenalty;
    }

    public void setProtectPenalty(int protectPenalty) {
        this._protectPenalty = protectPenalty;
    }

    public void addProtectPenalty(int protectPenalty) {
        this._protectPenalty += protectPenalty;
    }

    public ProtectionClientState getProtectState() {
        return this.protectState;
    }

    public void setProtectState(ProtectionClientState protectState) {
        this.protectState = protectState;
    }

    public final String getLoginName() {
        return this._loginName;
    }

    public void setLoginName(String name) {
        this._loginName = name;
    }

    public final String getPlayerName() {
        return this._playerName;
    }

    public void setPlayerName(String name) {
        this._playerName = name;
    }

    public int getPlayerId() {
        return this._playerId;
    }

    public void setPlayerId(int plId) {
        this._playerId = plId;
    }

    public String getIpAddr() {
        return this.IP;
    }

    public String toString() {
        if (!this._playerName.isEmpty() || this._playerId != 0) {
            return "PlayerName:" + this._playerName + "[" + String.valueOf(this._playerId) + "]HWID:" + this.HWID + "|IP:" + this.IP;
        }
        if (!this._loginName.isEmpty() || !this.HWID.isEmpty()) {
            return "LoginName:" + this._loginName + "|HWID:" + this.HWID + "|IP:" + this.IP;
        }
        if (this.IP.isEmpty()) {
            return "";
        }
        return "client - " + this.IP;
    }

    public void startOnlinerTask() {
        stopOnlinerTask(true);
        if (ConfigProtect.PROTECT_ONLINE_PACKET_TIME > 0) {
            this._onlinerTask = ThreadPoolManager.getInstance().scheduleGeneralAtFixedRate(new Onliner(this.client), (long) ConfigProtect.PROTECT_ONLINE_PACKET_TIME, (long) ConfigProtect.PROTECT_ONLINE_PACKET_TIME);
        }
    }

    public void stopOnlinerTask(boolean mayInterruptIfRunning) {
        if (this._onlinerTask != null) {
            try {
                this._onlinerTask.cancel(mayInterruptIfRunning);
            } catch (Exception e) {
            }
            this._onlinerTask = null;
        }
    }
}
