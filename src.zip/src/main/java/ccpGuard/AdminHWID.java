package ccpGuard;

import ccpGuard.managers.HwidBan;
import ccpGuard.managers.HwidInfo.LockType;
import ccpGuard.managers.HwidManager;
import ccpGuard.managers.ProtectManager;
import java.util.Iterator;
import java.util.StringTokenizer;
import ru.l2f.gameserver.handler.IAdminCommandHandler;
import ru.l2f.gameserver.model.L2Object;
import ru.l2f.gameserver.model.L2Player;

public class AdminHWID implements IAdminCommandHandler {
    private static String[] _adminCommands = new String[]{"admin_hwid_ban", "admin_hwid_reload", "admin_hwid_count", "admin_hwid_names", "admin_hwid_windows", "admin_hwid_lock_account", "admin_hwid_lock_player"};

    public boolean useAdminCommand(String command, L2Player player) {
        if (!ConfigProtect.PROTECT_ENABLE || player == null || !player.getPlayerAccess().CanHWID || !command.startsWith("admin_hwid")) {
            return false;
        }
        L2Player target;
        if (command.startsWith("admin_hwid_ban")) {
            L2Object plTarget = player.getTarget();
            if (plTarget == null) {
                player.sendMessage("Target is empty");
                return false;
            }
            target = plTarget.getPlayer();
            if (target != null) {
                HwidBan.addHwidBan(target.getNetConnection());
                player.sendMessage(target.getName() + " banned in HWID");
            } else {
                player.sendMessage("Target is not player");
            }
        } else if (command.startsWith("admin_hwid_reload")) {
            HwidBan.reload();
            player.sendMessage("HWID reload, " + HwidBan.getCountHwidBan() + " bans");
            HwidManager.reload();
            player.sendMessage("HwidManager reload, " + HwidManager.getCountHwidInfo() + " hwids");
        } else if (command.startsWith("admin_hwid_count")) {
            target = player.getTarget().getPlayer();
            if (target != null) {
                player.sendMessage(target.getName() + " has " + ProtectManager.getInstance().getCountByHWID(target.getNetConnection()._prot_info.getHWID()) + " connections opened.");
            } else {
                player.sendMessage("Target is not player");
            }
        } else if (command.startsWith("admin_hwid_names")) {
            target = player.getTarget().getPlayer();
            if (target != null) {
                player.sendMessage("Here all character's names by targeted character HWID:");
                Iterator i$ = ProtectManager.getInstance().getNamesByHWID(target.getNetConnection()._prot_info.getHWID()).iterator();
                while (i$.hasNext()) {
                    player.sendMessage((String) i$.next());
                }
            } else {
                player.sendMessage("Target is not player");
            }
        } else if (command.startsWith("admin_hwid_windows")) {
            try {
                StringTokenizer st = new StringTokenizer(command);
                if (st.countTokens() > 1) {
                    st.nextToken();
                    int windowsCount = Integer.parseInt(st.nextToken());
                    target = null;
                    if (player.getTarget() != null) {
                        target = player.getTarget().getPlayer();
                    } else {
                        player.sendMessage("Target is not player");
                    }
                    if (target != null) {
                        HwidManager.updateHwidInfo(target, windowsCount);
                        player.sendMessage(target.getName() + " set " + windowsCount + " allowed windows.");
                    } else {
                        player.sendMessage("Target is not player");
                    }
                }
            } catch (StringIndexOutOfBoundsException e) {
                player.sendMessage("Please specify new allowed windows count value.");
            }
        } else if (command.startsWith("admin_hwid_lock_account")) {
            if (!ConfigProtect.PROTECT_ENABLE_HWID_LOCK) {
                return false;
            }
            target = player.getTarget().getPlayer();
            if (target != null) {
                HwidManager.updateHwidInfo(player, LockType.ACCOUNT_LOCK);
                player.sendMessage(target.getName() + " was locked (account lock)");
            } else {
                player.sendMessage("Target is not player");
            }
        } else if (command.startsWith("admin_hwid_lock_player")) {
            if (!ConfigProtect.PROTECT_ENABLE_HWID_LOCK) {
                return false;
            }
            target = player.getTarget().getPlayer();
            if (target != null) {
                HwidManager.updateHwidInfo(player, LockType.PLAYER_LOCK);
                player.sendMessage(target.getName() + " was locked (account lock)");
            } else {
                player.sendMessage("Target is not player");
            }
        }
        return true;
    }

    public String[] getAdminCommandList() {
        return _adminCommands;
    }

    public String[] getDescription() {
        return new String[]{"no help", "no help", "no help", "no help", "no help", "no help", "no help"};
    }

    public String[] getCommandGroup() {
        return new String[]{"hwid", "hwid", "hwid", "hwid", "hwid", "hwid", "hwid"};
    }
}
