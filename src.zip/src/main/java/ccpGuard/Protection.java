package ccpGuard;

import ccpGuard.ProtectInfo.ProtectionClientState;
import ccpGuard.managers.HwidBan;
import ccpGuard.managers.HwidManager;
import ccpGuard.managers.ProtectManager;
import ccpGuard.utils.Util;
import java.nio.ByteBuffer;
import java.util.logging.Logger;
import ru.l2f.gameserver.handler.AdminCommandHandler;
import ru.l2f.gameserver.loginservercon.LSConnection;
import ru.l2f.gameserver.loginservercon.gspackets.ChangeAccessLevel;
import ru.l2f.gameserver.model.L2Player;
import ru.l2f.gameserver.network.L2GameClient;
import ru.l2f.gameserver.serverpackets.NpcHtmlMessage;
import ru.l2f.gameserver.serverpackets.ServerClose;
import ru.l2f.gameserver.serverpackets.SystemMessage;
import ru.l2f.util.Log;

public final class Protection {
    private static final Logger _log = Logger.getLogger(Protection.class.getName());
    private static String _logFile = "protection_logs";
    private static String[] _positionName = new String[]{"Ingame bot", "Cheat client console CMD: <Enabled>", "Cheat client hooked connect (maybe l2phx)", "Cheat client hooked send (maybe l2phx)", "Cheat client hooked recv (maybe l2phx)", "Unknow Soft"};
    public static boolean protect_use = false;

    public static void Init() {
        ConfigProtect.load();
        protect_use = ConfigProtect.PROTECT_ENABLE;
        if (protect_use) {
            _log.config("******************[ Protection System: Loading ]*******************");
            HwidBan.getInstance();
            HwidManager.getInstance();
            ProtectManager.getInstance();
            AdminCommandHandler.getInstance().registerAdminCommandHandler(new AdminHWID());
            _log.config("******************[ Protection System: Finish ]********************");
        }
    }

    public static boolean checkPlayerWithHWID(L2GameClient client, int playerID, String playerName) {
        if (!protect_use) {
            return true;
        }
        ProtectInfo pi = client._prot_info;
        pi.setPlayerId(playerID);
        if (ConfigProtect.PROTECT_ENABLE_HWID_LOCK && HwidManager.checkLockedHWID(pi)) {
            _log.info("An attempt to log in to locked character, " + pi.toString());
            client.close(new ServerClose());
            return false;
        }
        if (ConfigProtect.PROTECT_WINDOWS_COUNT != 0) {
            int count = ProtectManager.getInstance().getCountByHWID(pi.getHWID());
            if (count > ConfigProtect.PROTECT_WINDOWS_COUNT && count > HwidManager.getAllowedWindowsCount(pi)) {
                _log.info("Multi windows: " + pi.toString());
                client.close(new ServerClose());
                return false;
            }
        }
        addPlayer(pi);
        return true;
    }

    public static int calcPenalty(byte[] data, ProtectInfo pi) {
        int sum = -1;
        if (Util.verifyChecksum(data, 0, data.length)) {
            ByteBuffer buf = ByteBuffer.wrap(data, 0, data.length - 4);
            sum = 0;
            for (int i = 0; i < (data.length - 4) / 4; i++) {
                sum += dumpData(buf.getInt(), i, pi);
            }
        }
        return sum;
    }

    public static int dumpData(int _id, int position, ProtectInfo pi) {
        if (position > 4) {
            position = 5;
        }
        boolean isIdZero = false;
        if (_id == 0) {
            isIdZero = true;
            Log.add("Cannot read DumpId|Target:" + _positionName[position] + "|" + pi.toString() + "|DEBUG INFO:" + _id, _logFile);
        }
        switch (position) {
            case 0:
                if (_id == 1435233386) {
                    return 0;
                }
                if (!isIdZero) {
                    Log.add(_positionName[position] + " was found|" + pi.toString() + "|DEBUG INFO:" + _id, _logFile);
                }
                return ConfigProtect.PROTECT_PENALTY_IG;
            case 1:
                if (_id == 16) {
                    return 0;
                }
                if (!isIdZero) {
                    Log.add(_positionName[position] + " was found|" + pi.toString() + "|DEBUG INFO:" + _id, _logFile);
                }
                return ConfigProtect.PROTECT_PENALTY_CONSOLE_CMD;
            case 2:
            case 3:
            case 4:
                int code = _id & -16777216;
                if (code == 204) {
                    Log.add("Attempts!!! Debuger was found|" + pi.toString() + "|DEBUG INFO:" + _id, _logFile);
                }
                if (code != 233) {
                    return 0;
                }
                Log.add(_positionName[position] + " was found|" + pi.toString() + "|DEBUG INFO:" + _id, _logFile);
                return ConfigProtect.PROTECT_PENALTY_L2PHX;
            default:
                return 0;
        }
    }

    public static void checkProtocolVersion(L2GameClient client, int version) {
        ProtectionClientState pst = ProtectionClientState.DISABLED;
        if (protect_use) {
            if (version == ConfigProtect.PROTECT_PROTOCOL_VERSION) {
                pst = ProtectionClientState.ENABLED;
            } else {
                pst = ProtectionClientState.LIMITED;
            }
        }
        client._prot_info.setProtectState(pst);
        client._crypt.setState(pst);
    }

    public static String ExtractHWID(byte[] _data) {
        Util.doXORdecGG(_data, _data.length);
        if (!Util.verifyChecksum(_data, 0, _data.length)) {
            return "";
        }
        StringBuffer resultHWID = new StringBuffer();
        for (int i = 0; i < _data.length - 4; i++) {
            resultHWID.append(ru.l2f.util.Util.fillHex(_data[i] & 255, 2));
        }
        return resultHWID.toString();
    }

    public static boolean CheckHWIDs(ProtectInfo pi, int LastError1, int LastError2) {
        boolean resultHWID = false;
        boolean resultLastError = false;
        String HWID = pi.getHWID();
        String HWIDSec = pi.getHWIDSec();
        if (HWID.equalsIgnoreCase("fab800b1cc9de379c8046519fa841e6")) {
            Log.add("HWID:" + HWID + "|is empty, account:" + pi.getLoginName() + "|IP: " + pi.getIpAddr(), _logFile);
            if (ConfigProtect.PROTECT_KICK_WITH_EMPTY_HWID) {
                resultHWID = true;
            }
        }
        if (HWIDSec.equalsIgnoreCase("fab800b1cc9de379c8046519fa841e6")) {
            Log.add("Attempts!!! HWIDSec:" + HWIDSec + "|is empty, account:" + pi.getLoginName() + "|IP: " + pi.getIpAddr(), _logFile);
        }
        if (LastError1 != 0) {
            Log.add("LastError(HWID):" + LastError1 + "|" + Util.LastErrorConvertion(Integer.valueOf(LastError1)) + "|isn't empty, " + pi.toString(), _logFile);
            if (ConfigProtect.PROTECT_KICK_WITH_LASTERROR_HWID) {
                resultLastError = true;
            }
        }
        return resultHWID || resultLastError;
    }

    public static boolean BF_Init(int[] P, int[] S0, int[] S1, int[] S2, int[] S3) {
        return false;
    }

    public static void addPlayer(ProtectInfo pi) {
        if (protect_use && pi != null) {
            ProtectManager.getInstance().addPlayer(pi);
            pi.startOnlinerTask();
        }
    }

    public static void removePlayer(ProtectInfo pi) {
        if (protect_use && pi != null) {
            ProtectManager.getInstance().removePlayer(pi.getPlayerName());
            pi.stopOnlinerTask(true);
        }
    }

    public static void doReadAuthLogin(L2GameClient client, ByteBuffer buf, byte[] data) {
        if (protect_use) {
            int size = buf.remaining() - data.length;
            if (size < 0) {
                _log.info("Filed read AuthLogin! May be BOT or unprotected client! Client IP: " + client._prot_info.getIpAddr());
                client.close(new ServerClose());
                return;
            }
            if (size > 0) {
                buf.get(new byte[size]);
            }
            buf.get(data);
            buf.clear();
        }
    }

    public static boolean doAuthLogin(L2GameClient client, byte[] data, String loginName) {
        if (!protect_use) {
            return true;
        }
        ProtectInfo pi = client._prot_info;
        pi.setLoginName(loginName);
        String fullHWID = ExtractHWID(data);
        if (fullHWID.equals("")) {
            _log.info("AuthLogin CRC Check Fail! May be BOT or unprotected client! Client IP: " + pi.getIpAddr());
            client.close(new ServerClose());
            return false;
        }
        pi.setHWID(fullHWID.substring(0, 31));
        pi.setHWIDSec(fullHWID.substring(40, 71));
        Log.add(loginName + "|" + pi.getIpAddr() + "|" + pi.getHWID() + "|" + pi.getHWIDSec(), "hwid_log");
        if (CheckHWIDs(pi, ByteBuffer.wrap(data, 16, 4).getInt(), ByteBuffer.wrap(data, 36, 4).getInt())) {
            _log.info("HWID error, look protection_logs.txt file, from IP: " + client.getIpAddr());
            client.close(new ServerClose());
            return false;
        } else if (HwidBan.checkFullHWIDBanned(pi)) {
            Log.add("Rejected banned HWID main||HWID: " + pi.getHWID() + " IP: " + pi.getIpAddr(), _logFile);
            client.close(new ServerClose());
            return false;
        } else if (!ConfigProtect.PROTECT_ENABLE_HWID_LOCK || !HwidManager.checkLockedHWID(pi)) {
            return true;
        } else {
            Log.add("An attempt to log in to locked account||HWID: " + pi.getHWID() + " IP: " + pi.getIpAddr(), _logFile);
            client.close(new ServerClose());
            return false;
        }
    }

    public static void doReadReplyGameGuard(L2GameClient client, ByteBuffer buf, byte[] data) {
        if (protect_use) {
            int size = buf.remaining() - data.length;
            if (size < 0) {
                Log.add("Filed read ReplyGameGuardQuery! May be BOT or unprotected client!| " + client._prot_info.toString(), _logFile);
                client.close(new ServerClose());
                return;
            }
            if (size > 0) {
                buf.get(new byte[size]);
            }
            buf.get(data);
            buf.clear();
        }
    }

    public static void doReplyGameGuard(L2GameClient client, byte[] data) {
        if (protect_use || ConfigProtect.PROTECT_ENABLE_GG_SYSTEM) {
            ProtectInfo pi = client._prot_info;
            int penalty = calcPenalty(data, pi);
            if (penalty == -1) {
                Log.add("Checksumm (ReplyGameGuardQuery) is wrong|" + pi.toString(), _logFile);
                client.close(new ServerClose());
                return;
            }
            pi.addProtectPenalty(penalty);
            if (pi.getProtectPenalty() >= ConfigProtect.PROTECT_TOTAL_PENALTY) {
                L2Player player = client.getPlayer();
                if (player == null) {
                    Log.add("Cheater was found" + pi.toString(), _logFile);
                    client.close(new ServerClose());
                    return;
                }
                if (ConfigProtect.PROTECT_PUNISHMENT_ILLEGAL_SOFT == 0) {
                    Log.add("Cheater was found|" + pi.toString(), _logFile);
                    pi.setProtectPenalty(0);
                } else {
                    if (ConfigProtect.PROTECT_PUNISHMENT_ILLEGAL_SOFT == 1) {
                        Log.add("Cheater was kicked|" + pi.toString(), _logFile);
                    } else if (ConfigProtect.PROTECT_PUNISHMENT_ILLEGAL_SOFT == 2) {
                        LSConnection.getInstance().sendPacket(new ChangeAccessLevel(client.getLoginName(), -66, "Protect Autoban", -1));
                        player.setAccessLevel(-66);
                        Log.add("Cheater was banned|" + pi.toString(), _logFile);
                    } else if (ConfigProtect.PROTECT_PUNISHMENT_ILLEGAL_SOFT == 3) {
                        HwidBan.addHwidBan(client);
                        client.sendPacket(SystemMessage.sendString("You have been banned by HWID"));
                        LSConnection.getInstance().sendPacket(new ChangeAccessLevel(client.getLoginName(), -66, "Protect Autoban", -1));
                        player.setAccessLevel(-66);
                        Log.add("Cheater was banned, HWID ban| " + pi.toString(), _logFile);
                    }
                    if (!ConfigProtect.PROTECT_HTML_SHOW.equals("none")) {
                        client.close(new NpcHtmlMessage(5).setFile("data/html/" + ConfigProtect.PROTECT_HTML_SHOW));
                        return;
                    }
                }
                client.close(new ServerClose());
            }
        }
    }

    public static void doDisconection(L2GameClient client) {
        removePlayer(client._prot_info);
    }
}
