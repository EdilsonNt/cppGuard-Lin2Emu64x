package ccpGuard;

import ccpGuard.utils.NetList;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;
import java.util.logging.Logger;

public class ConfigProtect {
    public static int PROTECT_CONST_VALUE = 0;
    public static boolean PROTECT_DEBUG = false;
    public static boolean PROTECT_ENABLE = false;
    public static boolean PROTECT_ENABLE_GG_SYSTEM = false;
    public static boolean PROTECT_ENABLE_HWID_BANS = false;
    public static boolean PROTECT_ENABLE_HWID_LOCK = false;
    public static final String PROTECT_FILE = "./config/protection.properties";
    public static long PROTECT_GG_RECV_INTERVAL;
    public static long PROTECT_GG_SEND_INTERVAL;
    public static boolean PROTECT_GS_STORE_HWID;
    public static String PROTECT_HTML_SHOW;
    public static boolean PROTECT_HWID_PROBLEM_RESOLVED;
    public static boolean PROTECT_KICK_WITH_EMPTY_HWID;
    public static boolean PROTECT_KICK_WITH_LASTERROR_HWID;
    public static int PROTECT_ONLINE_PACKET_TIME;
    public static int PROTECT_PENALTY_ACP;
    public static int PROTECT_PENALTY_CONSOLE_CMD;
    public static int PROTECT_PENALTY_IG;
    public static int PROTECT_PENALTY_L2PHX;
    public static int PROTECT_PROTOCOL_VERSION;
    public static int PROTECT_PUNISHMENT_ILLEGAL_SOFT;
    public static long PROTECT_TASK_GG_INVERVAL;
    public static int PROTECT_TOTAL_PENALTY;
    public static NetList PROTECT_UNPROTECTED_IPS;
    public static int PROTECT_WINDOWS_COUNT;
    protected static Logger _log = Logger.getLogger(ConfigProtect.class.getName());

    public static void load() {
        File fp = new File(PROTECT_FILE);
        PROTECT_ENABLE = fp.exists();
        if (PROTECT_ENABLE) {
            try {
                Properties protectSettings = new Properties();
                InputStream is = new FileInputStream(fp);
                protectSettings.load(is);
                is.close();
                PROTECT_UNPROTECTED_IPS = new NetList();
                String _ips = getProperty(protectSettings, "UpProtectedIPs", "");
                if (_ips.equals("")) {
                    PROTECT_UNPROTECTED_IPS.LoadFromString(_ips, ",");
                }
                PROTECT_ENABLE = getBooleanProperty(protectSettings, "EnableProtect", true);
                PROTECT_CONST_VALUE = getIntProperty(protectSettings, "ServerConst", 0);
                PROTECT_WINDOWS_COUNT = getIntProperty(protectSettings, "AllowedWindowsCount", 99);
                PROTECT_PROTOCOL_VERSION = getIntProperty(protectSettings, "ProtectProtocolVersion", 777);
                PROTECT_KICK_WITH_EMPTY_HWID = getBooleanProperty(protectSettings, "KickWithEmptyHWID", true);
                PROTECT_KICK_WITH_LASTERROR_HWID = getBooleanProperty(protectSettings, "KickWithLastErrorHWID", false);
                PROTECT_ENABLE_HWID_LOCK = getBooleanProperty(protectSettings, "EnableHWIDLock", false);
                PROTECT_ENABLE_GG_SYSTEM = getBooleanProperty(protectSettings, "EnableGGSystem", true);
                PROTECT_DEBUG = getBooleanProperty(protectSettings, "ProtectDebug", false);
                PROTECT_HWID_PROBLEM_RESOLVED = getBooleanProperty(protectSettings, "HwidProblemResolved", false);
                PROTECT_GG_SEND_INTERVAL = getLongProperty(protectSettings, "GGSendInterval", 60000);
                PROTECT_GG_RECV_INTERVAL = getLongProperty(protectSettings, "GGRecvInterval", 8000);
                PROTECT_TASK_GG_INVERVAL = getLongProperty(protectSettings, "GGTaskInterval", 5000);
                PROTECT_TOTAL_PENALTY = getIntProperty(protectSettings, "TotalPenaltyPoint", 10);
                PROTECT_HTML_SHOW = getProperty(protectSettings, "ShowHtml", "none");
                PROTECT_PUNISHMENT_ILLEGAL_SOFT = getIntProperty(protectSettings, "PunishmentIllegalSoft", 1);
                PROTECT_PENALTY_IG = getIntProperty(protectSettings, "PenaltyIG", 10);
                PROTECT_PENALTY_L2PHX = getIntProperty(protectSettings, "PenaltyL2phx", 10);
                PROTECT_PENALTY_CONSOLE_CMD = getIntProperty(protectSettings, "PenaltyConsoleCMD", 1);
                PROTECT_ONLINE_PACKET_TIME = getIntProperty(protectSettings, "OnlinePacketTime", 0);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private static String getProperty(Properties prop, String name) {
        return prop.getProperty(name.trim(), null);
    }

    private static String getProperty(Properties prop, String name, String _default) {
        String s = getProperty(prop, name);
        return s == null ? _default : s;
    }

    private static int getIntProperty(Properties prop, String name, int _default) {
        String s = getProperty(prop, name);
        return s == null ? _default : Integer.parseInt(s.trim());
    }

    private static int getIntHexProperty(Properties prop, String name, int _default) {
        String s = getProperty(prop, name);
        if (s == null) {
            return _default;
        }
        s = s.trim();
        if (!s.startsWith("0x")) {
            s = "0x" + s;
        }
        return Integer.decode(s).intValue();
    }

    private static long getLongProperty(Properties prop, String name, long _default) {
        String s = getProperty(prop, name);
        return s == null ? _default : Long.parseLong(s.trim());
    }

    private static byte getByteProperty(Properties prop, String name, byte _default) {
        String s = getProperty(prop, name);
        return s == null ? _default : Byte.parseByte(s.trim());
    }

    private static byte getByteProperty(Properties prop, String name, int _default) {
        return getByteProperty(prop, name, (byte) _default);
    }

    private static boolean getBooleanProperty(Properties prop, String name, boolean _default) {
        String s = getProperty(prop, name);
        return s == null ? _default : Boolean.parseBoolean(s.trim());
    }

    private static float getFloatProperty(Properties prop, String name, float _default) {
        String s = getProperty(prop, name);
        return s == null ? _default : Float.parseFloat(s.trim());
    }

    private static float getFloatProperty(Properties prop, String name, double _default) {
        return getFloatProperty(prop, name, (float) _default);
    }

    private static double getDoubleProperty(Properties prop, String name, double _default) {
        String s = getProperty(prop, name);
        return s == null ? _default : Double.parseDouble(s.trim());
    }

    private ConfigProtect() {
    }
}
