package ccpGuard.utils;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.LineNumberReader;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

public final class NetList {
    private final List<Net> _Nets = new ArrayList();

    public boolean AddNet(String address) {
        if (address == null || address.length() == 0 || address.startsWith("#") || address.startsWith("#") || address.startsWith("#")) {
            return false;
        }
        this._Nets.add(new Net(address.trim()));
        return true;
    }

    public int LoadFromLines(List lines) {
        int added = 0;
        if (lines == null) {
            return 0;
        }
        for (int i = 0; i < lines.size(); i++) {
            if (AddNet((String) lines.get(i))) {
                added++;
            }
        }
        return added;
    }

    public int LoadFromFile(String fn) {
        if (fn == null || fn.length() == 0) {
            return 0;
        }
        int added = 0;
        try {
            LineNumberReader lnr = new LineNumberReader(new BufferedReader(new FileReader(fn)));
            while (true) {
                String line = lnr.readLine();
                if (line == null) {
                    return added;
                }
                if (AddNet(line)) {
                    added++;
                }
            }
        } catch (Exception e) {
            return 0;
        }
    }

    public int LoadFromString(String _s, String _regex) {
        int added = 0;
        if (_s == null || _regex == null || _s.length() == 0 || _regex.length() == 0) {
            return 0;
        }
        for (String ip : _s.split(_regex)) {
            if (AddNet(ip)) {
                added++;
            }
        }
        return added;
    }

    public int ipInNet(String ip) {
        for (int i = 0; i < this._Nets.size(); i++) {
            if (((Net) this._Nets.get(i)).isInNet(ip)) {
                return i;
            }
        }
        return -1;
    }

    public boolean isIpInNets(String ip) {
        return ipInNet(ip) != -1;
    }

    public int NetsCount() {
        return this._Nets.size();
    }

    public void ClearNets() {
        this._Nets.clear();
    }

    private byte[] IntToBytes(int i) {
        return new byte[]{(byte) ((i >> 24) & 255), (byte) ((i >> 16) & 255), (byte) ((i >> 8) & 255), (byte) (i & 255)};
    }

    public String NetByIndex(int i) {
        if (this._Nets.size() <= i) {
            return "";
        }
        Net _net = (Net) this._Nets.get(i);
        try {
            return InetAddress.getByAddress(IntToBytes(_net.getNet())).getHostAddress() + "/" + InetAddress.getByAddress(IntToBytes(_net.getMask())).getHostAddress();
        } catch (UnknownHostException e) {
            return "";
        }
    }

    public void PrintOut() {
        for (int i = 0; i < this._Nets.size(); i++) {
            System.out.println("  Net #" + i + ": " + NetByIndex(i));
        }
    }
}
