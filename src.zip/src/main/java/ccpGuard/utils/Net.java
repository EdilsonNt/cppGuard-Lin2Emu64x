package ccpGuard.utils;

import java.util.StringTokenizer;

public class Net {
    private final int _mask;
    private final int _net;

    public Net(int net, int mask) {
        this._net = net;
        this._mask = mask;
    }

    public Net(String net, int mask) {
        this._net = AddrToint(net);
        this._mask = mask;
    }

    public Net(String net, String mask) {
        this._net = AddrToint(net);
        this._mask = AddrToint(mask);
    }

    public Net(int net, String mask) {
        this._net = net;
        this._mask = AddrToint(mask);
    }

    public Net(String net_mask) {
        StringTokenizer st = new StringTokenizer(net_mask.trim(), "/");
        this._net = AddrToint(st.nextToken());
        if (st.hasMoreTokens()) {
            this._mask = AddrToint(st.nextToken());
        } else {
            this._mask = -1;
        }
    }

    public boolean isInNet(int _ip) {
        return (this._mask & _ip) == this._net;
    }

    public boolean isInNet(String addr) {
        return isInNet(AddrToint(addr));
    }

    public boolean equal(Net _Net) {
        return _Net.getNet() == this._net && _Net.getMask() == this._mask;
    }

    private int AddrToint(String addr) {
        int _ip = 0;
        StringTokenizer st = new StringTokenizer(addr.trim(), ".");
        int _dots = st.countTokens();
        if (_dots == 1) {
            try {
                int _bitmask = Integer.parseInt(st.nextToken());
                if (_bitmask <= 0) {
                    return 0;
                }
                if (_bitmask < 32) {
                    return -1 << (32 - _bitmask);
                }
                return -1;
            } catch (NumberFormatException e) {
                return -1;
            }
        }
        for (int i = 0; i < _dots; i++) {
            try {
                _ip += Integer.parseInt(st.nextToken()) << (24 - (i * 8));
            } catch (NumberFormatException e2) {
            }
        }
        return _ip;
    }

    public int getNet() {
        return this._net;
    }

    public int getMask() {
        return this._mask;
    }
}
