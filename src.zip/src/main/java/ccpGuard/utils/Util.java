package ccpGuard.utils;

public class Util {
    public static String LastErrorConvertion(Integer LastError) {
        return LastError.toString();
    }

    private static String fillHex(int data, int digits) {
        String number = Integer.toHexString(data);
        for (int i = number.length(); i < digits; i++) {
            number = "0" + number;
        }
        return number;
    }

    public static int doXORdecGG(byte[] data, int data_len) {
        int ecx = bytesToInt(data, 0);
        intToBytes(bytesToInt(data, 0) ^ ecx, data, 0);
        for (int pos = data_len - 4; pos >= 0; pos -= 4) {
            int edx = bytesToInt(data, pos) ^ ecx;
            ecx -= edx;
            intToBytes(edx, data, pos);
        }
        return ecx;
    }

    public static boolean verifyChecksum(byte[] raw, int offset, int size) {
        if ((size & 3) != 0 || size <= 4) {
            return false;
        }
        long chksum = 0;
        int count = size - 4;
        for (int i = offset; i < count; i += 4) {
            chksum ^= (long) bytesToInt(raw, i);
        }
        if (((long) bytesToInt(raw, count)) == chksum) {
            return true;
        }
        return false;
    }

    public static int bytesToInt(byte[] array, int offset) {
        int offset2 = offset + 1;
        offset = offset2 + 1;
        offset2 = offset + 1;
        offset = offset2 + 1;
        return (((array[offset] & 255) | ((array[offset2] & 255) << 8)) | ((array[offset] & 255) << 16)) | ((array[offset2] & 255) << 24);
    }

    public static void intToBytes(int value, byte[] array, int offset) {
        int i = offset + 1;
        array[offset] = (byte) (value & 255);
        offset = i + 1;
        array[i] = (byte) ((value >> 8) & 255);
        i = offset + 1;
        array[offset] = (byte) ((value >> 16) & 255);
        offset = i + 1;
        array[i] = (byte) ((value >> 24) & 255);
    }
}
